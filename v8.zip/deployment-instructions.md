# Deployment Instructions for Health Department Application

## Server Setup

1. Upload all files to your server
2. Make sure Node.js and MySQL are installed
3. Install required dependencies:
   ```
   npm install
   ```

## Database Setup

1. Create the database and admin user:
   ```
   mysql -h bt.orisys.in -u root -p < setup.sql
   ```

2. Create application tables:
   ```
   mysql -h bt.orisys.in -u root -p formv3 < create_tables.sql
   ```

## Starting the Server

1. Start the server using the provided script:
   ```
   ./start-server.sh
   ```

2. The server will run on port 3001 by default

3. To stop the server:
   ```
   ./stop-server.sh
   ```

## Admin Login

Use the following credentials to log in to the admin dashboard:
- Username: admin
- Password: admin123

## Environment Variables

The following environment variables can be set in the .env file:

```
VITE_API_URL=http://bt.orisys.in:3001
VITE_DATABASE_HOST=bt.orisys.in
VITE_DATABASE_USER=root
VITE_DATABASE_PASSWORD=iotwaterdb!fh
VITE_DATABASE_NAME=formv3
VITE_JWT_SECRET=your_jwt_secret_key
```

## Troubleshooting

1. If the server fails to start, check the server.log file for errors
2. If database connection fails, verify the database credentials in the .env file
3. For form submission issues, check that the API URL is correctly set
