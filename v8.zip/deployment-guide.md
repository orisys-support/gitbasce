# Deployment Guide for Health Department Application

## 1. Server Setup

```bash
# Update package lists
sudo apt update
sudo apt upgrade -y

# Install essential tools
sudo apt install -y curl wget git build-essential
```

## 2. Install Node.js and npm

```bash
# Install Node.js 18.x (LTS)
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Verify installation
node -v
npm -v
```

## 3. Install MySQL Server

```bash
# Install MySQL
sudo apt install -y mysql-server

# Secure MySQL installation
sudo mysql_secure_installation

# Start MySQL service and enable on boot
sudo systemctl start mysql
sudo systemctl enable mysql
```

## 4. Create Database and User

```bash
# Login to MySQL as root
sudo mysql
```

In MySQL prompt:
```sql
-- Create database
CREATE DATABASE health_department_app;

-- Create user and grant privileges
CREATE USER 'healthapp'@'localhost' IDENTIFIED BY 'your_strong_password';
GRANT ALL PRIVILEGES ON health_department_app.* TO 'healthapp'@'localhost';
FLUSH PRIVILEGES;

-- Exit MySQL
EXIT;
```

## 5. Import Database Schema

```bash
# Import the schema
sudo mysql health_department_app < /path/to/database_schema.sql
```

## 6. Clone and Set Up Application

```bash
# Create directory for application
mkdir -p /var/www/health-app
cd /var/www/health-app

# Clone your repository (replace with your actual repository URL)
git clone https://your-repository-url.git .

# Install dependencies
npm install

# Create .env file for environment variables
cat > .env << EOL
VITE_BASE_PATH=/
VITE_API_URL=http://your-server-domain/api
VITE_DATABASE_HOST=localhost
VITE_DATABASE_USER=healthapp
VITE_DATABASE_PASSWORD=your_strong_password
VITE_DATABASE_NAME=health_department_app
EOL
```

## 7. Build the Application

```bash
# Build the application
npm run build
```

## 8. Set Up Nginx as Web Server

```bash
# Install Nginx
sudo apt install -y nginx

# Start Nginx and enable on boot
sudo systemctl start nginx
sudo systemctl enable nginx

# Configure firewall if enabled
sudo ufw allow 'Nginx Full'
```

## 9. Configure Nginx for the Application

```bash
# Create Nginx configuration file
sudo nano /etc/nginx/sites-available/health-app
```

Add the following configuration:
```nginx
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;

    root /var/www/health-app/dist;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    # API proxy configuration (if you have a separate API server)
    location /api/ {
        proxy_pass http://localhost:3000/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
# Enable the site
sudo ln -s /etc/nginx/sites-available/health-app /etc/nginx/sites-enabled/

# Test Nginx configuration
sudo nginx -t

# Reload Nginx to apply changes
sudo systemctl reload nginx
```

## 10. Set Up Backend API Server (if needed)

If your application requires a backend API server:

```bash
# Install PM2 for process management
sudo npm install -g pm2

# Navigate to your API directory (if separate from frontend)
cd /var/www/health-app/api

# Start the API server with PM2
pm2 start server.js --name health-api

# Make PM2 start on boot
pm2 startup
sudo env PATH=$PATH:/usr/bin pm2 startup systemd -u ubuntu --hp /home/ubuntu
pm2 save
```

## 11. Set Up SSL with Let's Encrypt

```bash
# Install Certbot
sudo apt install -y certbot python3-certbot-nginx

# Obtain SSL certificate
sudo certbot --nginx -d your-domain.com -d www.your-domain.com

# Verify auto-renewal is set up
sudo systemctl status certbot.timer
```

## 12. Regular Maintenance

```bash
# Set up a simple backup script for the database
cat > /home/ubuntu/backup-db.sh << EOL
#!/bin/bash
BACKUP_DIR="/home/ubuntu/backups"
DATETIME=\$(date +"%Y-%m-%d_%H-%M-%S")
MYSQL_USER="healthapp"
MYSQL_PASSWORD="your_strong_password"
DATABASE="health_department_app"

mkdir -p \$BACKUP_DIR
mysqldump -u\$MYSQL_USER -p\$MYSQL_PASSWORD \$DATABASE > \$BACKUP_DIR/\$DATABASE-\$DATETIME.sql
gzip \$BACKUP_DIR/\$DATABASE-\$DATETIME.sql
EOL

chmod +x /home/ubuntu/backup-db.sh

# Set up a cron job for daily backups at 2 AM
(crontab -l 2>/dev/null; echo "0 2 * * * /home/ubuntu/backup-db.sh") | crontab -
```

## Troubleshooting

### Database Connection Issues

```bash
# Check MySQL service status
sudo systemctl status mysql

# Check MySQL logs
sudo tail -f /var/log/mysql/error.log

# Test database connection
mysql -u healthapp -p -e "USE health_department_app; SHOW TABLES;"
```

### Web Server Issues

```bash
# Check Nginx status
sudo systemctl status nginx

# Check Nginx error logs
sudo tail -f /var/log/nginx/error.log

# Check application access logs
sudo tail -f /var/log/nginx/access.log
```

### Application Issues

```bash
# Check PM2 process status (if using PM2)
pm2 status
pm2 logs

# Check application logs
tail -f /var/www/health-app/logs/app.log
```

## Security Considerations

1. **Firewall Configuration**:
   ```bash
   sudo ufw enable
   sudo ufw allow ssh
   sudo ufw allow 'Nginx Full'
   sudo ufw status
   ```

2. **Regular Updates**:
   ```bash
   sudo apt update
   sudo apt upgrade -y
   ```

3. **Database Security**:
   - Use strong passwords
   - Limit database user privileges
   - Regularly backup your database

4. **File Permissions**:
   ```bash
   # Set proper ownership
   sudo chown -R www-data:www-data /var/www/health-app
   
   # Set proper permissions
   sudo find /var/www/health-app -type d -exec chmod 755 {} \;
   sudo find /var/www/health-app -type f -exec chmod 644 {} \;
   ```

5. **Environment Variables**:
   - Never commit .env files to version control
   - Use secure methods to manage secrets

## Monitoring

Consider setting up monitoring for your application:

```bash
# Install Node.js monitoring tool
sudo npm install -g pm2

# Start your application with PM2
pm2 start npm --name "health-app" -- run start

# Monitor application
pm2 monit
```
