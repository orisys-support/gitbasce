# Health and Family Welfare Department - Administrative Post Application System

## Overview

This application system allows healthcare professionals to apply for administrative posts in the Health and Family Welfare Department. It includes a comprehensive form for applicants and an admin dashboard for reviewing and managing applications.

## Features

### Public-facing Form
- Complete application form for administrative posts with the following sections:
  - Personal Details
  - Educational Qualifications & Trainings
  - Service Details
  - Performance and Achievements
  - Departmental Enquiry / Disciplinary Record
  - Declaration & Undertaking
- Form validation on both client and server sides
- Responsive design for all devices

### Admin Dashboard
- Secure login portal with session management
- Comprehensive view of all submitted applications
- Search, filter, and sort functionality
- Export capabilities for application data
- Application status management (Pending, Approved, Rejected)

## Technical Details

### Frontend
- Built with React and TypeScript
- UI components from Shadcn UI library
- Form validation using React Hook Form and Zod
- Responsive design with Tailwind CSS

### Backend
- MySQL database for data storage
- RESTful API endpoints for form submission and data retrieval
- Secure authentication for admin users

## Database Schema

The application uses a MySQL database with the following main tables:
- `admin_users`: Stores admin user credentials and information
- `applications`: Stores all application form data
- `application_documents`: Stores uploaded documents related to applications
- `application_status_history`: Tracks changes to application status

For detailed schema information, see the `database_schema.sql` file.

## Setup Instructions

1. Clone the repository
2. Install dependencies: `npm install`
3. Set up the database using the schema in `database_schema.sql`
4. Configure environment variables
5. Start the development server: `npm run dev`

## Admin Access

Default admin credentials:
- Username: admin
- Password: password

**Important:** Change the default password after first login in a production environment.
