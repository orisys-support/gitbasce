// This is a simple Express server for handling API requests

const express = require("express");
const mysql = require("mysql2/promise");
const cors = require("cors");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const app = express();
const PORT = process.env.PORT || 3002;

// Middleware
app.use(cors());
app.use(express.json());

// Database connection
const pool = mysql.createPool({
  host: process.env.DB_HOST || "bt.orisys.in",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "iotwaterdb!fh",
  database: process.env.DB_NAME || "formv3",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

// Test database connection
async function testDbConnection() {
  try {
    const connection = await pool.getConnection();
    console.log("Database connection successful");
    connection.release();
  } catch (error) {
    console.error("Database connection failed:", error);
  }
}

testDbConnection();

// JWT Secret
const JWT_SECRET = process.env.JWT_SECRET || "your_jwt_secret_key";

// Authentication middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];

  if (!token)
    return res.status(401).json({ message: "Authentication required" });

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err)
      return res.status(403).json({ message: "Invalid or expired token" });
    req.user = user;
    next();
  });
};

// Login endpoint
app.post("/login", async (req, res) => {
  try {
    const { username, password } = req.body;

    // Get user from database
    const [rows] = await pool.execute(
      "SELECT * FROM admin_users WHERE username = ?",
      [username],
    );

    if (rows.length === 0) {
      return res.status(401).json({ message: "Invalid username or password" });
    }

    const user = rows[0];

    // Compare password
    const passwordMatch = await bcrypt.compare(password, user.password_hash);

    if (!passwordMatch) {
      return res.status(401).json({ message: "Invalid username or password" });
    }

    // Update last login time
    await pool.execute(
      "UPDATE admin_users SET last_login = NOW() WHERE id = ?",
      [user.id],
    );

    // Generate JWT token
    const token = jwt.sign(
      { id: user.id, username: user.username, role: user.role },
      JWT_SECRET,
      { expiresIn: "8h" },
    );

    res.json({
      token,
      user: {
        id: user.id,
        username: user.username,
        fullName: user.full_name,
        role: user.role,
      },
    });
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({ message: "Server error" });
  }
});

// Get all submissions
app.get("/submissions", authenticateToken, async (req, res) => {
  try {
    const [rows] = await pool.execute(
      "SELECT * FROM applications ORDER BY submitted_at DESC",
    );
    res.json(rows);
  } catch (error) {
    console.error("Error fetching submissions:", error);
    res.status(500).json({ message: "Server error" });
  }
});

// Get submission by ID
app.get("/submissions/:id", authenticateToken, async (req, res) => {
  try {
    const [rows] = await pool.execute(
      "SELECT * FROM applications WHERE id = ?",
      [req.params.id],
    );

    if (rows.length === 0) {
      return res.status(404).json({ message: "Submission not found" });
    }

    res.json(rows[0]);
  } catch (error) {
    console.error("Error fetching submission:", error);
    res.status(500).json({ message: "Server error" });
  }
});

// Update submission status
app.patch("/submissions/:id/status", authenticateToken, async (req, res) => {
  try {
    const { status, notes } = req.body;
    const submissionId = req.params.id;
    const reviewerId = req.user.id;

    // Get current status
    const [currentStatusRows] = await pool.execute(
      "SELECT status FROM applications WHERE id = ?",
      [submissionId],
    );

    if (currentStatusRows.length === 0) {
      return res.status(404).json({ message: "Submission not found" });
    }

    const previousStatus = currentStatusRows[0].status;

    // Update status
    await pool.execute(
      "UPDATE applications SET status = ?, reviewer_id = ?, review_notes = ? WHERE id = ?",
      [status, reviewerId, notes, submissionId],
    );

    // Record status change in history
    await pool.execute(
      "INSERT INTO application_status_history (application_id, previous_status, new_status, changed_by, notes) VALUES (?, ?, ?, ?, ?)",
      [submissionId, previousStatus, status, reviewerId, notes],
    );

    res.json({ message: "Status updated successfully" });
  } catch (error) {
    console.error("Error updating status:", error);
    res.status(500).json({ message: "Server error" });
  }
});

// Submit new application
app.post("/applications", async (req, res) => {
  try {
    const application = req.body;

    // Insert application into database
    const [result] = await pool.execute(
      `INSERT INTO applications (
        post_applied_for, full_name, kgid_number, date_of_birth, mobile_number, email,
        mbbs_institution, mbbs_year, pg_degree, pg_institution, pg_university, pg_year,
        deputed_by_government, specialist_service, training_hospital_admin,
        date_initial_appointment, sl_no_in_order, order_no_date, date_appointment_contract,
        appointing_authority, compulsory_rural_service_places, compulsory_rural_service_duration,
        probation_declaration, past_designations, current_posting_designation, current_posting_period,
        contract_service_details, timebound_6year, timebound_6year_order, timebound_6year_date,
        timebound_13year, timebound_13year_order, timebound_13year_date, timebound_20year,
        timebound_20year_order, timebound_20year_date, spouse_govt_service, administrative_roles,
        additional_charges, significant_achievements, special_achievements, departmental_enquiries,
        suspension_periods, punishments_received, criminal_proceedings, pending_legal_matters,
        declaration_date, declaration_place, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        application.postAppliedFor,
        application.fullName,
        application.kgidNumber,
        application.dateOfBirth,
        application.mobileNumber,
        application.email,
        application.mbbs_institution,
        application.mbbs_year,
        application.pg_degree || null,
        application.pg_institution || null,
        application.pg_university || null,
        application.pg_year || null,
        application.deputed_by_government || false,
        application.specialist_service || null,
        application.training_hospital_admin || false,
        application.date_initial_appointment,
        application.sl_no_in_order,
        application.order_no_date,
        application.date_appointment_contract || null,
        application.appointing_authority || null,
        application.compulsory_rural_service_places || null,
        application.compulsory_rural_service_duration || null,
        application.probation_declaration || null,
        application.past_designations || null,
        application.current_posting_designation,
        application.current_posting_period,
        application.contract_service_details || null,
        application.timebound_6year || false,
        application.timebound_6year_order || null,
        application.timebound_6year_date || null,
        application.timebound_13year || false,
        application.timebound_13year_order || null,
        application.timebound_13year_date || null,
        application.timebound_20year || false,
        application.timebound_20year_order || null,
        application.timebound_20year_date || null,
        application.spouse_govt_service || null,
        application.administrative_roles || null,
        application.additional_charges || null,
        application.significant_achievements || null,
        application.special_achievements || null,
        application.departmental_enquiries || null,
        application.suspension_periods || null,
        application.punishments_received || null,
        application.criminal_proceedings || null,
        application.pending_legal_matters || null,
        application.declaration_date,
        application.declaration_place,
        "Pending",
      ],
    );

    res.status(201).json({
      message: "Application submitted successfully",
      applicationId: result.insertId,
    });
  } catch (error) {
    console.error("Error submitting application:", error);
    res.status(500).json({ message: "Server error" });
  }
});

// Export endpoint
app.get("/export/excel", authenticateToken, async (req, res) => {
  try {
    const selectedIds = req.query.ids
      ? req.query.ids.split(",").map(Number)
      : [];

    // Build query based on selected IDs or get all
    let query = "SELECT * FROM applications";
    let params = [];

    if (selectedIds.length > 0) {
      query += " WHERE id IN (?)";
      params = [selectedIds];
    }

    query += " ORDER BY submitted_at DESC";

    const [rows] = await pool.execute(query, params);

    // Generate Excel file using xlsx library
    const xlsx = require("xlsx");
    const workbook = xlsx.utils.book_new();
    const worksheet = xlsx.utils.json_to_sheet(rows);

    // Add worksheet to workbook
    xlsx.utils.book_append_sheet(workbook, worksheet, "Submissions");

    // Generate buffer
    const excelBuffer = xlsx.write(workbook, {
      type: "buffer",
      bookType: "xlsx",
    });

    // Set headers for file download
    res.setHeader(
      "Content-Type",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    );
    res.setHeader(
      "Content-Disposition",
      "attachment; filename=submissions.xlsx",
    );

    // Send the file
    res.send(excelBuffer);
  } catch (error) {
    console.error("Export error:", error);
    res.status(500).json({ message: "Server error" });
  }
});

// Root endpoint for testing connection
app.get("/", (req, res) => {
  res.json({ message: "Health Department API Server is running" });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
