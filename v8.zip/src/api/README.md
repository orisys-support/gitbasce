# Health Department API Server

## Overview

This is a simple Express.js API server for the Health Department Application. It provides endpoints for user authentication, form submission, and admin operations.

## Setup

1. Install dependencies:
   ```
   npm install
   ```

2. Set environment variables (create a `.env` file):
   ```
   DB_HOST=localhost
   DB_USER=healthapp
   DB_PASSWORD=your_strong_password
   DB_NAME=health_department_app
   JWT_SECRET=your_jwt_secret_key
   PORT=3000
   ```

3. Start the server:
   ```
   npm start
   ```

## API Endpoints

### Authentication

- **POST /login**
  - Authenticates admin users
  - Request body: `{ "username": "admin", "password": "password" }`
  - Response: `{ "token": "jwt_token", "user": { ... } }`

### Applications

- **POST /applications**
  - Submits a new application
  - Request body: Application form data
  - Response: `{ "message": "Application submitted successfully", "applicationId": 123 }`

### Admin Operations

- **GET /submissions**
  - Gets all form submissions
  - Requires authentication
  - Response: Array of submissions

- **GET /submissions/:id**
  - Gets a specific submission by ID
  - Requires authentication
  - Response: Submission details

- **PATCH /submissions/:id/status**
  - Updates the status of a submission
  - Requires authentication
  - Request body: `{ "status": "Approved", "notes": "Approved by admin" }`
  - Response: `{ "message": "Status updated successfully" }`

## Authentication

All admin endpoints require a JWT token in the Authorization header:

```
Authorization: Bearer your_jwt_token
```
