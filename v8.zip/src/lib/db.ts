import mysql from "mysql2/promise";

// Database connection configuration
const dbConfig = {
  host: process.env.VITE_DATABASE_HOST || "localhost",
  user: process.env.VITE_DATABASE_USER || "healthapp",
  password: process.env.VITE_DATABASE_PASSWORD || "your_strong_password",
  database: process.env.VITE_DATABASE_NAME || "health_department_app",
};

// Create a connection pool
const pool = mysql.createPool(dbConfig);

// Helper function to execute queries
export async function query(sql: string, params: any[] = []) {
  try {
    const [results] = await pool.execute(sql, params);
    return results;
  } catch (error) {
    console.error("Database query error:", error);
    throw error;
  }
}

// Test database connection
export async function testConnection() {
  try {
    const connection = await pool.getConnection();
    console.log("Database connection successful");
    connection.release();
    return true;
  } catch (error) {
    console.error("Database connection failed:", error);
    return false;
  }
}

export default {
  query,
  testConnection,
};
