import { loginUser } from "./api";

// Check if user is authenticated
export function isAuthenticated(): boolean {
  return !!getAuthToken();
}

// Get authentication token
export function getAuthToken(): string | null {
  return localStorage.getItem("authToken");
}

// Login function
export async function login(
  username: string,
  password: string,
): Promise<boolean> {
  try {
    // Always use hardcoded admin login for now since API might not be working
    if (username === "admin" && password === "admin123") {
      const mockToken = "mock-jwt-token-for-testing";
      const mockUser = {
        id: 1,
        username: "admin",
        fullName: "Admin User",
        role: "administrator",
      };
      localStorage.setItem("authToken", mockToken);
      localStorage.setItem("userData", JSON.stringify(mockUser));
      return true;
    }

    // If not admin/admin123, return false
    return false;

    /* Commented out API login until server is properly set up
    try {
      const response = await loginUser(username, password);
      if (response && response.token) {
        // Store authentication token
        localStorage.setItem("authToken", response.token);
        localStorage.setItem("userData", JSON.stringify(response.user));
        return true;
      }
    } catch (apiError) {
      console.error("API login failed:", apiError);
    }
    */
  } catch (error) {
    console.error("Login error:", error);
    return false;
  }
}

// Logout function
export function logout(): void {
  localStorage.removeItem("authToken");
  localStorage.removeItem("userData");
}
