const API_BASE_URL = "http://bt.orisys.in:3002";

export async function fetchSubmissions(token: string) {
  try {
    const response = await fetch(`${API_BASE_URL}/submissions`, {
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
    });

    if (!response.ok) {
      throw new Error(`Error fetching submissions: ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error("API error:", error);
    throw error;
  }
}

export async function updateSubmissionStatus(
  id: number,
  status: string,
  notes: string,
  token: string,
) {
  try {
    const response = await fetch(`${API_BASE_URL}/submissions/${id}/status`, {
      method: "PATCH",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ status, notes }),
    });

    if (!response.ok) {
      throw new Error(`Error updating status: ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error("API error:", error);
    throw error;
  }
}

export async function loginUser(username: string, password: string) {
  try {
    // Check if API is reachable first
    try {
      const testResponse = await fetch(`${API_BASE_URL}`, { method: "GET" });
      if (!testResponse.ok) {
        console.error("API server not reachable");
        throw new Error("API server not reachable");
      }
    } catch (e) {
      console.error("API connection error:", e);
      throw new Error("Cannot connect to API server");
    }

    const response = await fetch(`${API_BASE_URL}/login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ username, password }),
    });

    if (!response.ok) {
      throw new Error(`Login failed: ${response.status}`);
    }

    const contentType = response.headers.get("content-type");
    if (!contentType || !contentType.includes("application/json")) {
      throw new Error("Server returned non-JSON response");
    }

    return await response.json();
  } catch (error) {
    console.error("Login error:", error);
    throw error;
  }
}

export async function exportSubmissionsToExcel(
  selectedIds: number[] = [],
  token: string,
) {
  try {
    const queryParams =
      selectedIds.length > 0 ? `?ids=${selectedIds.join(",")}` : "";

    const response = await fetch(`${API_BASE_URL}/export/excel${queryParams}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      throw new Error(`Export failed: ${response.status}`);
    }

    return await response.blob();
  } catch (error) {
    console.error("Export error:", error);
    throw error;
  }
}
