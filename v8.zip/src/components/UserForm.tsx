import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CheckCircle, AlertCircle } from "lucide-react";

const formSchema = z.object({
  // Section 1: Personal Details
  postAppliedFor: z
    .string()
    .min(1, { message: "Post applied for is required" }),
  fullName: z.string().min(2, { message: "Full name is required" }),
  kgidNumber: z.string().min(1, { message: "KGID Number is required" }),
  dateOfBirth: z.string().min(1, { message: "Date of birth is required" }),
  mobileNumber: z
    .string()
    .min(10, { message: "Valid mobile number is required" }),
  email: z.string().email({ message: "Valid email is required" }),

  // Section 2: Educational Qualifications & Trainings
  mbbs_institution: z
    .string()
    .min(1, { message: "MBBS institution is required" }),
  mbbs_year: z.string().min(1, { message: "Year of graduation is required" }),
  pg_degree: z.string().optional(),
  pg_institution: z.string().optional(),
  pg_university: z.string().optional(),
  pg_year: z.string().optional(),
  deputed_by_government: z.boolean().optional(),
  specialist_service: z.string().optional(),
  training_hospital_admin: z.boolean().optional(),

  // Section 3: Service Details
  date_initial_appointment: z
    .string()
    .min(1, { message: "Date of initial appointment is required" }),
  sl_no_in_order: z
    .string()
    .min(1, { message: "Serial number in order is required" }),
  order_no_date: z
    .string()
    .min(1, { message: "Order number and date is required" }),
  date_appointment_contract: z.string().optional(),
  appointing_authority: z.string().optional(),
  compulsory_rural_service_places: z.string().optional(),
  compulsory_rural_service_duration: z.string().optional(),
  probation_declaration: z.string().optional(),
  past_designations: z.string().optional(),
  current_posting_designation: z
    .string()
    .min(1, { message: "Current posting designation is required" }),
  current_posting_period: z
    .string()
    .min(1, { message: "Current posting period is required" }),
  contract_service_details: z.string().optional(),
  timebound_6year: z.boolean().optional(),
  timebound_6year_order: z.string().optional(),
  timebound_6year_date: z.string().optional(),
  timebound_13year: z.boolean().optional(),
  timebound_13year_order: z.string().optional(),
  timebound_13year_date: z.string().optional(),
  timebound_20year: z.boolean().optional(),
  timebound_20year_order: z.string().optional(),
  timebound_20year_date: z.string().optional(),
  spouse_govt_service: z.string().optional(),
  administrative_roles: z.string().optional(),
  additional_charges: z.string().optional(),

  // Section 4: Performance and Achievements
  significant_achievements: z.string().optional(),
  special_achievements: z.string().optional(),

  // Section 5: Departmental Enquiry / Disciplinary Record
  departmental_enquiries: z.string().optional(),
  suspension_periods: z.string().optional(),
  punishments_received: z.string().optional(),
  criminal_proceedings: z.string().optional(),
  pending_legal_matters: z.string().optional(),

  // Section 6: Declaration & Undertaking
  declaration_date: z
    .string()
    .min(1, { message: "Declaration date is required" }),
  declaration_place: z
    .string()
    .min(1, { message: "Declaration place is required" }),
  agree_to_declaration: z.boolean().refine((val) => val === true, {
    message: "You must agree to the declaration",
  }),
});

type FormValues = z.infer<typeof formSchema>;

const UserForm = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
    watch,
  } = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      postAppliedFor: "",
      fullName: "",
      kgidNumber: "",
      dateOfBirth: "",
      mobileNumber: "",
      email: "",
      mbbs_institution: "",
      mbbs_year: "",
      pg_degree: "",
      pg_institution: "",
      pg_university: "",
      pg_year: "",
      deputed_by_government: false,
      specialist_service: "",
      training_hospital_admin: false,
      date_initial_appointment: "",
      sl_no_in_order: "",
      order_no_date: "",
      date_appointment_contract: "",
      appointing_authority: "",
      compulsory_rural_service_places: "",
      compulsory_rural_service_duration: "",
      probation_declaration: "",
      past_designations: "",
      current_posting_designation: "",
      current_posting_period: "",
      contract_service_details: "",
      timebound_6year: false,
      timebound_6year_order: "",
      timebound_6year_date: "",
      timebound_13year: false,
      timebound_13year_order: "",
      timebound_13year_date: "",
      timebound_20year: false,
      timebound_20year_order: "",
      timebound_20year_date: "",
      spouse_govt_service: "",
      administrative_roles: "",
      additional_charges: "",
      significant_achievements: "",
      special_achievements: "",
      departmental_enquiries: "",
      suspension_periods: "",
      punishments_received: "",
      criminal_proceedings: "",
      pending_legal_matters: "",
      declaration_date: "",
      declaration_place: "",
      agree_to_declaration: false,
    },
  });

  const onSubmit = async (data: FormValues) => {
    setIsSubmitting(true);
    setSubmitError(null);

    try {
      // For demo purposes, simulate a successful submission
      // instead of making an actual API call that might fail
      console.log("Form data submitted:", data);

      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 1500));

      // Simulate successful response
      setSubmitSuccess(true);
      reset();

      /* Commented out actual API call until server is properly set up
      const apiUrl = "http://bt.orisys.in:3002";
      const response = await fetch(`${apiUrl}/applications`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        throw new Error(`Server responded with status: ${response.status}`);
      }

      const result = await response.json();
      console.log("Form submission result:", result);

      setSubmitSuccess(true);
      reset();
      */
    } catch (error) {
      setSubmitError(
        "There was an error submitting the form. Please try again.",
      );
      console.error("Form submission error:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReset = () => {
    reset();
    setSubmitSuccess(false);
    setSubmitError(null);
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-4 bg-background">
      {submitSuccess ? (
        <Card>
          <CardHeader>
            <CardTitle className="text-center text-2xl">
              Application Submitted Successfully!
            </CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col items-center">
            <div className="rounded-full bg-green-100 p-3 mb-4">
              <CheckCircle className="h-10 w-10 text-green-600" />
            </div>
            <p className="text-center mb-6">
              Thank you for submitting your application. Your form has been
              received and will be reviewed by the Health and Family Welfare
              Department.
            </p>
            <Button onClick={handleReset}>Submit Another Application</Button>
          </CardContent>
        </Card>
      ) : (
        <form onSubmit={handleSubmit(onSubmit)}>
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">
                Application for Administrative Post in the Health and Family
                Welfare Department
              </CardTitle>
              <CardDescription>
                Reference: Government Order No: ಆಕುಕ 156 ಹೆಚ್‌ ಎಸ್‌ಹೆಚ್ 2025,
                Dated: 24-04-2025
              </CardDescription>
            </CardHeader>

            <CardContent>
              <Tabs defaultValue="personal" className="w-full">
                <TabsList className="grid w-full grid-cols-6 mb-8">
                  <TabsTrigger value="post">Post</TabsTrigger>
                  <TabsTrigger value="personal">Personal</TabsTrigger>
                  <TabsTrigger value="education">Education</TabsTrigger>
                  <TabsTrigger value="service">Service</TabsTrigger>
                  <TabsTrigger value="performance">Performance</TabsTrigger>
                  <TabsTrigger value="declaration">Declaration</TabsTrigger>
                </TabsList>

                {/* Post Applied For */}
                <TabsContent value="post" className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="postAppliedFor">Post Applied For *</Label>
                    <Input
                      id="postAppliedFor"
                      {...register("postAppliedFor")}
                      placeholder="Please specify the post you are applying for"
                      className={errors.postAppliedFor ? "border-red-500" : ""}
                    />
                    {errors.postAppliedFor && (
                      <p className="text-red-500 text-sm">
                        {errors.postAppliedFor.message}
                      </p>
                    )}
                  </div>
                </TabsContent>

                {/* Section 1: Personal Details */}
                <TabsContent value="personal" className="space-y-4">
                  <h3 className="text-lg font-semibold">
                    Section 1: Personal Details
                  </h3>

                  <div className="space-y-2">
                    <Label htmlFor="fullName">
                      Full Name (in BLOCK letters) *
                    </Label>
                    <Input
                      id="fullName"
                      {...register("fullName")}
                      placeholder="Enter your full name"
                      className={errors.fullName ? "border-red-500" : ""}
                    />
                    {errors.fullName && (
                      <p className="text-red-500 text-sm">
                        {errors.fullName.message}
                      </p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="kgidNumber">KGID Number *</Label>
                    <Input
                      id="kgidNumber"
                      {...register("kgidNumber")}
                      placeholder="Enter your KGID Number"
                      className={errors.kgidNumber ? "border-red-500" : ""}
                    />
                    {errors.kgidNumber && (
                      <p className="text-red-500 text-sm">
                        {errors.kgidNumber.message}
                      </p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="dateOfBirth">
                      Date of Birth (DD/MM/YYYY) *
                    </Label>
                    <Input
                      id="dateOfBirth"
                      type="date"
                      {...register("dateOfBirth")}
                      className={errors.dateOfBirth ? "border-red-500" : ""}
                    />
                    {errors.dateOfBirth && (
                      <p className="text-red-500 text-sm">
                        {errors.dateOfBirth.message}
                      </p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="mobileNumber">Mobile Number *</Label>
                    <Input
                      id="mobileNumber"
                      type="tel"
                      {...register("mobileNumber")}
                      placeholder="Enter your mobile number"
                      className={errors.mobileNumber ? "border-red-500" : ""}
                    />
                    {errors.mobileNumber && (
                      <p className="text-red-500 text-sm">
                        {errors.mobileNumber.message}
                      </p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email ID *</Label>
                    <Input
                      id="email"
                      type="email"
                      {...register("email")}
                      placeholder="Enter your email address"
                      className={errors.email ? "border-red-500" : ""}
                    />
                    {errors.email && (
                      <p className="text-red-500 text-sm">
                        {errors.email.message}
                      </p>
                    )}
                  </div>
                </TabsContent>

                {/* Section 2: Educational Qualifications & Trainings */}
                <TabsContent value="education" className="space-y-4">
                  <h3 className="text-lg font-semibold">
                    Section 2: Educational Qualifications & Trainings
                  </h3>

                  <div className="border p-4 rounded-md space-y-4">
                    <h4 className="font-medium">MBBS</h4>
                    <div className="space-y-2">
                      <Label htmlFor="mbbs_institution">Institution *</Label>
                      <Input
                        id="mbbs_institution"
                        {...register("mbbs_institution")}
                        placeholder="Enter MBBS institution name"
                        className={
                          errors.mbbs_institution ? "border-red-500" : ""
                        }
                      />
                      {errors.mbbs_institution && (
                        <p className="text-red-500 text-sm">
                          {errors.mbbs_institution.message}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="mbbs_year">Year of Graduation *</Label>
                      <Input
                        id="mbbs_year"
                        {...register("mbbs_year")}
                        placeholder="Enter year of graduation"
                        className={errors.mbbs_year ? "border-red-500" : ""}
                      />
                      {errors.mbbs_year && (
                        <p className="text-red-500 text-sm">
                          {errors.mbbs_year.message}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="border p-4 rounded-md space-y-4">
                    <h4 className="font-medium">Postgraduate Qualification</h4>
                    <div className="space-y-2">
                      <Label htmlFor="pg_degree">Degree</Label>
                      <Input
                        id="pg_degree"
                        {...register("pg_degree")}
                        placeholder="Enter postgraduate degree"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="pg_institution">Institution</Label>
                      <Input
                        id="pg_institution"
                        {...register("pg_institution")}
                        placeholder="Enter postgraduate institution"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="pg_university">University</Label>
                      <Input
                        id="pg_university"
                        {...register("pg_university")}
                        placeholder="Enter university name"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="pg_year">Year of Completion</Label>
                      <Input
                        id="pg_year"
                        {...register("pg_year")}
                        placeholder="Enter year of completion"
                      />
                    </div>

                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="deputed_by_government"
                        onCheckedChange={(checked) =>
                          setValue("deputed_by_government", checked === true)
                        }
                      />
                      <Label htmlFor="deputed_by_government">
                        Deputed by Government
                      </Label>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="specialist_service">
                      Specialist Service in Department (if any)
                    </Label>
                    <Textarea
                      id="specialist_service"
                      {...register("specialist_service")}
                      placeholder="Details of service rendered as a specialist in the concerned discipline (include designation and duration)"
                      rows={3}
                    />
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="training_hospital_admin"
                      onCheckedChange={(checked) =>
                        setValue("training_hospital_admin", checked === true)
                      }
                    />
                    <Label htmlFor="training_hospital_admin">
                      Training in Hospital Administration (minimum 1 month)
                    </Label>
                  </div>
                </TabsContent>

                {/* Section 3: Service Details */}
                <TabsContent value="service" className="space-y-4">
                  <h3 className="text-lg font-semibold">
                    Section 3: Service Details
                  </h3>

                  <div className="space-y-2">
                    <Label htmlFor="date_initial_appointment">
                      Date of Initial Appointment (Regular) *
                    </Label>
                    <Input
                      id="date_initial_appointment"
                      type="date"
                      {...register("date_initial_appointment")}
                      className={
                        errors.date_initial_appointment ? "border-red-500" : ""
                      }
                    />
                    {errors.date_initial_appointment && (
                      <p className="text-red-500 text-sm">
                        {errors.date_initial_appointment.message}
                      </p>
                    )}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="sl_no_in_order">Sl. No. in Order *</Label>
                      <Input
                        id="sl_no_in_order"
                        {...register("sl_no_in_order")}
                        className={
                          errors.sl_no_in_order ? "border-red-500" : ""
                        }
                      />
                      {errors.sl_no_in_order && (
                        <p className="text-red-500 text-sm">
                          {errors.sl_no_in_order.message}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="order_no_date">Order No. & Date *</Label>
                      <Input
                        id="order_no_date"
                        {...register("order_no_date")}
                        className={errors.order_no_date ? "border-red-500" : ""}
                      />
                      {errors.order_no_date && (
                        <p className="text-red-500 text-sm">
                          {errors.order_no_date.message}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="date_appointment_contract">
                        Date of Appointment (Contract, if any)
                      </Label>
                      <Input
                        id="date_appointment_contract"
                        type="date"
                        {...register("date_appointment_contract")}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="appointing_authority">
                        Appointing Authority, Order No. & Date
                      </Label>
                      <Input
                        id="appointing_authority"
                        {...register("appointing_authority")}
                      />
                    </div>
                  </div>

                  <div className="border p-4 rounded-md space-y-4">
                    <h4 className="font-medium">
                      Compulsory Rural Service after Regular Recruitment (6
                      Years)
                    </h4>
                    <div className="space-y-2">
                      <Label htmlFor="compulsory_rural_service_places">
                        Place(s)
                      </Label>
                      <Input
                        id="compulsory_rural_service_places"
                        {...register("compulsory_rural_service_places")}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="compulsory_rural_service_duration">
                        Duration (From – To)
                      </Label>
                      <Input
                        id="compulsory_rural_service_duration"
                        {...register("compulsory_rural_service_duration")}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="probation_declaration">
                      Probation Declaration Details
                    </Label>
                    <Input
                      id="probation_declaration"
                      {...register("probation_declaration")}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="past_designations">
                      Past Designations Held
                    </Label>
                    <Textarea
                      id="past_designations"
                      {...register("past_designations")}
                      placeholder="Designation(s), Period(s)"
                      rows={2}
                    />
                  </div>

                  <div className="border p-4 rounded-md space-y-4">
                    <h4 className="font-medium">Current Posting *</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="current_posting_designation">
                          Designation
                        </Label>
                        <Input
                          id="current_posting_designation"
                          {...register("current_posting_designation")}
                          className={
                            errors.current_posting_designation
                              ? "border-red-500"
                              : ""
                          }
                        />
                        {errors.current_posting_designation && (
                          <p className="text-red-500 text-sm">
                            {errors.current_posting_designation.message}
                          </p>
                        )}
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="current_posting_period">Period</Label>
                        <Input
                          id="current_posting_period"
                          {...register("current_posting_period")}
                          className={
                            errors.current_posting_period
                              ? "border-red-500"
                              : ""
                          }
                        />
                        {errors.current_posting_period && (
                          <p className="text-red-500 text-sm">
                            {errors.current_posting_period.message}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="contract_service_details">
                      Contract Service Details (if any)
                    </Label>
                    <Input
                      id="contract_service_details"
                      {...register("contract_service_details")}
                      placeholder="Designation, Period"
                    />
                  </div>

                  <div className="border p-4 rounded-md space-y-4">
                    <h4 className="font-medium">Service Bonds</h4>

                    <div className="space-y-4">
                      <div className="flex items-start space-x-2">
                        <div className="pt-1">
                          <Checkbox
                            id="timebound_6year"
                            onCheckedChange={(checked) =>
                              setValue("timebound_6year", checked === true)
                            }
                          />
                        </div>
                        <div className="space-y-1 flex-1">
                          <Label htmlFor="timebound_6year">
                            6-Year Timebound
                          </Label>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                            <Input
                              id="timebound_6year_order"
                              {...register("timebound_6year_order")}
                              placeholder="Order No."
                            />
                            <Input
                              id="timebound_6year_date"
                              type="date"
                              {...register("timebound_6year_date")}
                              placeholder="Date"
                            />
                          </div>
                        </div>
                      </div>

                      <div className="flex items-start space-x-2">
                        <div className="pt-1">
                          <Checkbox
                            id="timebound_13year"
                            onCheckedChange={(checked) =>
                              setValue("timebound_13year", checked === true)
                            }
                          />
                        </div>
                        <div className="space-y-1 flex-1">
                          <Label htmlFor="timebound_13year">
                            13-Year Timebound
                          </Label>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                            <Input
                              id="timebound_13year_order"
                              {...register("timebound_13year_order")}
                              placeholder="Order No."
                            />
                            <Input
                              id="timebound_13year_date"
                              type="date"
                              {...register("timebound_13year_date")}
                              placeholder="Date"
                            />
                          </div>
                        </div>
                      </div>

                      <div className="flex items-start space-x-2">
                        <div className="pt-1">
                          <Checkbox
                            id="timebound_20year"
                            onCheckedChange={(checked) =>
                              setValue("timebound_20year", checked === true)
                            }
                          />
                        </div>
                        <div className="space-y-1 flex-1">
                          <Label htmlFor="timebound_20year">
                            20-Year Timebound
                          </Label>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                            <Input
                              id="timebound_20year_order"
                              {...register("timebound_20year_order")}
                              placeholder="Order No."
                            />
                            <Input
                              id="timebound_20year_date"
                              type="date"
                              {...register("timebound_20year_date")}
                              placeholder="Date"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="spouse_govt_service">
                      If Spouse is in Government Service
                    </Label>
                    <Input
                      id="spouse_govt_service"
                      {...register("spouse_govt_service")}
                      placeholder="Department and Designation Place of Working"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="administrative_roles">
                      Administrative Roles Held
                    </Label>
                    <Input
                      id="administrative_roles"
                      {...register("administrative_roles")}
                      placeholder="MO Admin / THO / Programme Officer"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="additional_charges">
                      Additional Charges Held (if any)
                    </Label>
                    <Input
                      id="additional_charges"
                      {...register("additional_charges")}
                      placeholder="Designation, Duration"
                    />
                  </div>
                </TabsContent>

                {/* Section 4: Performance and Achievements */}
                <TabsContent value="performance" className="space-y-4">
                  <h3 className="text-lg font-semibold">
                    Section 4: Performance and Achievements
                  </h3>

                  <div className="space-y-2">
                    <Label htmlFor="significant_achievements">
                      1. Significant achievement in previous work performance
                    </Label>
                    <Textarea
                      id="significant_achievements"
                      {...register("significant_achievements")}
                      placeholder="Problem-solving initiatives, Leadership and Analytical Skills"
                      rows={4}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="special_achievements">
                      2. Special Achievements / Awards / Innovations /
                      Publications
                    </Label>
                    <Textarea
                      id="special_achievements"
                      {...register("special_achievements")}
                      rows={4}
                    />
                  </div>

                  <h3 className="text-lg font-semibold mt-6">
                    Section 5: Departmental Enquiry / Disciplinary Record
                  </h3>

                  <div className="space-y-2">
                    <Label htmlFor="departmental_enquiries">
                      1. Past/ Ongoing/ Pending departmental enquiries
                    </Label>
                    <Input
                      id="departmental_enquiries"
                      {...register("departmental_enquiries")}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="suspension_periods">
                      2. Suspension periods (if any)
                    </Label>
                    <Input
                      id="suspension_periods"
                      {...register("suspension_periods")}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="punishments_received">
                      3. Any punishment received
                    </Label>
                    <Input
                      id="punishments_received"
                      {...register("punishments_received")}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="criminal_proceedings">
                      4. Criminal Proceedings – Yes/No, if yes provide details
                    </Label>
                    <Input
                      id="criminal_proceedings"
                      {...register("criminal_proceedings")}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="pending_legal_matters">
                      5. Pending legal matters (KAT/High Court/Supreme Court)
                    </Label>
                    <Input
                      id="pending_legal_matters"
                      {...register("pending_legal_matters")}
                    />
                  </div>
                </TabsContent>

                {/* Section 6: Declaration & Undertaking */}
                <TabsContent value="declaration" className="space-y-4">
                  <h3 className="text-lg font-semibold">
                    Section 6: Declaration & Undertaking
                  </h3>

                  <div className="border p-4 rounded-md bg-gray-50">
                    <p className="text-sm">
                      I hereby declare that all the information furnished in
                      this application is true, complete, and correct to the
                      best of my knowledge and belief.
                      <br />
                      <br />I understand that my application is subject to
                      verification and approval by the competent authority, and
                      that the final decision of the Department in this regard
                      shall be binding.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="declaration_date">Date *</Label>
                      <Input
                        id="declaration_date"
                        type="date"
                        {...register("declaration_date")}
                        className={
                          errors.declaration_date ? "border-red-500" : ""
                        }
                      />
                      {errors.declaration_date && (
                        <p className="text-red-500 text-sm">
                          {errors.declaration_date.message}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="declaration_place">Place *</Label>
                      <Input
                        id="declaration_place"
                        {...register("declaration_place")}
                        className={
                          errors.declaration_place ? "border-red-500" : ""
                        }
                      />
                      {errors.declaration_place && (
                        <p className="text-red-500 text-sm">
                          {errors.declaration_place.message}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center space-x-2 pt-4">
                    <Checkbox
                      id="agree_to_declaration"
                      onCheckedChange={(checked) =>
                        setValue("agree_to_declaration", checked === true)
                      }
                    />
                    <Label htmlFor="agree_to_declaration" className="text-sm">
                      I agree to the above declaration *
                    </Label>
                  </div>
                  {errors.agree_to_declaration && (
                    <p className="text-red-500 text-sm">
                      {errors.agree_to_declaration.message}
                    </p>
                  )}
                </TabsContent>
              </Tabs>

              {submitError && (
                <Alert variant="destructive" className="mt-6">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{submitError}</AlertDescription>
                </Alert>
              )}
            </CardContent>

            <CardFooter className="flex justify-between bg-muted/10">
              <Button type="button" variant="outline" onClick={handleReset}>
                Reset
              </Button>
              <Button
                type="submit"
                disabled={isSubmitting}
                className="bg-primary hover:bg-primary/90"
              >
                {isSubmitting ? "Submitting..." : "Submit Application"}
              </Button>
            </CardFooter>
          </Card>
        </form>
      )}
    </div>
  );
};

export default UserForm;
