import React, { useState } from "react";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";
import {
  Download,
  Search,
  Filter,
  ChevronDown,
  ChevronUp,
  Eye,
} from "lucide-react";

interface Submission {
  id: number;
  fullName: string;
  email: string;
  kgidNumber: string;
  mobileNumber: string;
  postAppliedFor: string;
  mbbs_institution: string;
  current_posting_designation: string;
  status: string;
  submittedAt: string;
}

interface SubmissionsTableProps {
  submissions?: Submission[];
  onExport?: (selectedIds: number[]) => void;
  onSearch?: (query: string) => void;
  onFilter?: (filter: Record<string, string>) => void;
  searchQuery?: string;
  filterStatus?: string;
  dateRange?: string;
}

const SubmissionsTable = ({
  submissions = mockSubmissions,
  onExport = () => {},
  onSearch = () => {},
  onFilter = () => {},
  searchQuery: externalSearchQuery = "",
  filterStatus: externalFilterStatus = "all",
  dateRange: externalDateRange = "all",
}: SubmissionsTableProps) => {
  const [searchQuery, setSearchQuery] = useState(externalSearchQuery);
  const [selectedSubmissions, setSelectedSubmissions] = useState<number[]>([]);
  const [sortField, setSortField] = useState<keyof Submission>("submittedAt");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");
  const [currentPage, setCurrentPage] = useState(1);
  const [statusFilter, setStatusFilter] =
    useState<string>(externalFilterStatus);
  const [formTypeFilter, setFormTypeFilter] = useState<string>("all");

  const itemsPerPage = 10;

  // Handle search input change
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
    onSearch(e.target.value);
  };

  // Handle sort column click
  const handleSort = (field: keyof Submission) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  // Handle checkbox selection
  const handleSelectSubmission = (id: number) => {
    setSelectedSubmissions((prev) => {
      if (prev.includes(id)) {
        return prev.filter((item) => item !== id);
      } else {
        return [...prev, id];
      }
    });
  };

  // Handle select all checkbox
  const handleSelectAll = () => {
    if (selectedSubmissions.length === filteredSubmissions.length) {
      setSelectedSubmissions([]);
    } else {
      setSelectedSubmissions(filteredSubmissions.map((sub) => sub.id));
    }
  };

  // Handle export button click
  const handleExport = () => {
    onExport(selectedSubmissions);
  };

  // Apply filters
  const filteredSubmissions = submissions.filter((submission) => {
    const matchesSearch =
      submission.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      submission.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      submission.kgidNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      submission.postAppliedFor
        .toLowerCase()
        .includes(searchQuery.toLowerCase());

    const matchesStatus =
      statusFilter === "all" || submission.status === statusFilter;
    const matchesFormType =
      formTypeFilter === "all" || submission.postAppliedFor === formTypeFilter;

    return matchesSearch && matchesStatus && matchesFormType;
  });

  // Apply sorting
  const sortedSubmissions = [...filteredSubmissions].sort((a, b) => {
    if (a[sortField] < b[sortField]) return sortDirection === "asc" ? -1 : 1;
    if (a[sortField] > b[sortField]) return sortDirection === "asc" ? 1 : -1;
    return 0;
  });

  // Apply pagination
  const paginatedSubmissions = sortedSubmissions.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage,
  );

  const totalPages = Math.ceil(filteredSubmissions.length / itemsPerPage);

  // Get unique form types and statuses for filters
  const formTypes = Array.from(
    new Set(submissions.map((sub) => sub.postAppliedFor)),
  );
  const statuses = Array.from(new Set(submissions.map((sub) => sub.status)));

  return (
    <div className="w-full bg-white rounded-lg shadow-md p-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
        <div className="relative w-full md:w-64">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search applications..."
            value={searchQuery}
            onChange={handleSearchChange}
            className="pl-8"
          />
        </div>

        <div className="flex flex-col md:flex-row gap-2 w-full md:w-auto">
          <div className="flex items-center gap-2">
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                {statuses.map((status) => (
                  <SelectItem key={status} value={status}>
                    {status}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={formTypeFilter} onValueChange={setFormTypeFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by post" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Posts</SelectItem>
                {formTypes.map((type) => (
                  <SelectItem key={type} value={type}>
                    {type}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Button
            variant="outline"
            onClick={handleExport}
            disabled={selectedSubmissions.length === 0}
            className="whitespace-nowrap"
          >
            <Download className="mr-2 h-4 w-4" />
            Export Selected
          </Button>
        </div>
      </div>

      <div className="border rounded-md overflow-hidden">
        <Table>
          <TableCaption>
            A list of all administrative post applications.
          </TableCaption>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[50px]">
                <Checkbox
                  checked={
                    selectedSubmissions.length === filteredSubmissions.length &&
                    filteredSubmissions.length > 0
                  }
                  onCheckedChange={handleSelectAll}
                />
              </TableHead>
              <TableHead
                className="cursor-pointer"
                onClick={() => handleSort("id")}
              >
                ID
                {sortField === "id" &&
                  (sortDirection === "asc" ? (
                    <ChevronUp className="inline ml-1 h-4 w-4" />
                  ) : (
                    <ChevronDown className="inline ml-1 h-4 w-4" />
                  ))}
              </TableHead>
              <TableHead
                className="cursor-pointer"
                onClick={() => handleSort("fullName")}
              >
                Name
                {sortField === "fullName" &&
                  (sortDirection === "asc" ? (
                    <ChevronUp className="inline ml-1 h-4 w-4" />
                  ) : (
                    <ChevronDown className="inline ml-1 h-4 w-4" />
                  ))}
              </TableHead>
              <TableHead
                className="cursor-pointer"
                onClick={() => handleSort("kgidNumber")}
              >
                KGID Number
                {sortField === "kgidNumber" &&
                  (sortDirection === "asc" ? (
                    <ChevronUp className="inline ml-1 h-4 w-4" />
                  ) : (
                    <ChevronDown className="inline ml-1 h-4 w-4" />
                  ))}
              </TableHead>
              <TableHead
                className="cursor-pointer"
                onClick={() => handleSort("postAppliedFor")}
              >
                Post Applied For
                {sortField === "postAppliedFor" &&
                  (sortDirection === "asc" ? (
                    <ChevronUp className="inline ml-1 h-4 w-4" />
                  ) : (
                    <ChevronDown className="inline ml-1 h-4 w-4" />
                  ))}
              </TableHead>
              <TableHead
                className="cursor-pointer"
                onClick={() => handleSort("current_posting_designation")}
              >
                Current Designation
                {sortField === "current_posting_designation" &&
                  (sortDirection === "asc" ? (
                    <ChevronUp className="inline ml-1 h-4 w-4" />
                  ) : (
                    <ChevronDown className="inline ml-1 h-4 w-4" />
                  ))}
              </TableHead>
              <TableHead
                className="cursor-pointer"
                onClick={() => handleSort("status")}
              >
                Status
                {sortField === "status" &&
                  (sortDirection === "asc" ? (
                    <ChevronUp className="inline ml-1 h-4 w-4" />
                  ) : (
                    <ChevronDown className="inline ml-1 h-4 w-4" />
                  ))}
              </TableHead>
              <TableHead
                className="cursor-pointer"
                onClick={() => handleSort("submittedAt")}
              >
                Submitted At
                {sortField === "submittedAt" &&
                  (sortDirection === "asc" ? (
                    <ChevronUp className="inline ml-1 h-4 w-4" />
                  ) : (
                    <ChevronDown className="inline ml-1 h-4 w-4" />
                  ))}
              </TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {paginatedSubmissions.length > 0 ? (
              paginatedSubmissions.map((submission) => (
                <TableRow key={submission.id}>
                  <TableCell>
                    <Checkbox
                      checked={selectedSubmissions.includes(submission.id)}
                      onCheckedChange={() =>
                        handleSelectSubmission(submission.id)
                      }
                    />
                  </TableCell>
                  <TableCell>{submission.id}</TableCell>
                  <TableCell className="font-medium">
                    {submission.fullName}
                  </TableCell>
                  <TableCell>{submission.kgidNumber}</TableCell>
                  <TableCell>{submission.postAppliedFor}</TableCell>
                  <TableCell>
                    {submission.current_posting_designation}
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        submission.status === "Approved"
                          ? "default"
                          : submission.status === "Pending"
                            ? "secondary"
                            : "outline"
                      }
                    >
                      {submission.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {new Date(submission.submittedAt).toLocaleString()}
                  </TableCell>
                  <TableCell>
                    <Button variant="ghost" size="sm">
                      <Eye className="h-4 w-4" />
                      <span className="sr-only">View</span>
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell
                  colSpan={9}
                  className="text-center py-8 text-muted-foreground"
                >
                  No applications found
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {totalPages > 1 && (
        <div className="mt-4">
          <Pagination>
            <PaginationContent>
              <PaginationItem>
                <PaginationPrevious
                  onClick={() =>
                    setCurrentPage((prev) => Math.max(prev - 1, 1))
                  }
                  className={
                    currentPage === 1 ? "pointer-events-none opacity-50" : ""
                  }
                />
              </PaginationItem>

              {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                // Show first page, last page, current page, and pages around current
                let pageNum;
                if (totalPages <= 5) {
                  pageNum = i + 1;
                } else if (currentPage <= 3) {
                  pageNum = i + 1;
                } else if (currentPage >= totalPages - 2) {
                  pageNum = totalPages - 4 + i;
                } else {
                  pageNum = currentPage - 2 + i;
                }

                return (
                  <PaginationItem key={pageNum}>
                    <PaginationLink
                      isActive={currentPage === pageNum}
                      onClick={() => setCurrentPage(pageNum)}
                    >
                      {pageNum}
                    </PaginationLink>
                  </PaginationItem>
                );
              })}

              {totalPages > 5 && currentPage < totalPages - 2 && (
                <PaginationItem>
                  <PaginationEllipsis />
                </PaginationItem>
              )}

              {totalPages > 5 && currentPage < totalPages - 2 && (
                <PaginationItem>
                  <PaginationLink onClick={() => setCurrentPage(totalPages)}>
                    {totalPages}
                  </PaginationLink>
                </PaginationItem>
              )}

              <PaginationItem>
                <PaginationNext
                  onClick={() =>
                    setCurrentPage((prev) => Math.min(prev + 1, totalPages))
                  }
                  className={
                    currentPage === totalPages
                      ? "pointer-events-none opacity-50"
                      : ""
                  }
                />
              </PaginationItem>
            </PaginationContent>
          </Pagination>
        </div>
      )}
    </div>
  );
};

// Mock data for development
const mockSubmissions: Submission[] = [
  {
    id: 1,
    fullName: "Dr. Rajesh Kumar",
    email: "rajesh.kumar@health.gov.in",
    kgidNumber: "KGID12345",
    mobileNumber: "9876543210",
    postAppliedFor: "District Health Officer",
    mbbs_institution: "Bangalore Medical College",
    current_posting_designation: "Medical Officer",
    status: "Pending",
    submittedAt: "2025-05-10T10:30:00Z",
  },
  {
    id: 2,
    fullName: "Dr. Priya Sharma",
    email: "priya.sharma@health.gov.in",
    kgidNumber: "KGID23456",
    mobileNumber: "8765432109",
    postAppliedFor: "Taluk Health Officer",
    mbbs_institution: "Mysore Medical College",
    current_posting_designation: "Medical Officer",
    status: "Approved",
    submittedAt: "2025-05-08T14:45:00Z",
  },
  {
    id: 3,
    fullName: "Dr. Suresh Gowda",
    email: "suresh.gowda@health.gov.in",
    kgidNumber: "KGID34567",
    mobileNumber: "7654321098",
    postAppliedFor: "Joint Director",
    mbbs_institution: "KMC Manipal",
    current_posting_designation: "Taluk Health Officer",
    status: "Pending",
    submittedAt: "2025-05-12T09:15:00Z",
  },
  {
    id: 4,
    fullName: "Dr. Meena Patil",
    email: "meena.patil@health.gov.in",
    kgidNumber: "KGID45678",
    mobileNumber: "6543210987",
    postAppliedFor: "District Health Officer",
    mbbs_institution: "JNMC Belgaum",
    current_posting_designation: "Medical Officer",
    status: "Rejected",
    submittedAt: "2025-05-05T11:20:00Z",
  },
  {
    id: 5,
    fullName: "Dr. Arun Shetty",
    email: "arun.shetty@health.gov.in",
    kgidNumber: "KGID56789",
    mobileNumber: "5432109876",
    postAppliedFor: "Deputy Director",
    mbbs_institution: "St. John's Medical College",
    current_posting_designation: "District Health Officer",
    status: "Approved",
    submittedAt: "2025-05-03T16:50:00Z",
  },
  {
    id: 6,
    fullName: "Dr. Kavitha Rao",
    email: "kavitha.rao@health.gov.in",
    kgidNumber: "KGID67890",
    mobileNumber: "4321098765",
    postAppliedFor: "Joint Director",
    mbbs_institution: "MS Ramaiah Medical College",
    current_posting_designation: "Taluk Health Officer",
    status: "Pending",
    submittedAt: "2025-05-14T08:10:00Z",
  },
  {
    id: 7,
    fullName: "Dr. Venkatesh Murthy",
    email: "venkatesh.murthy@health.gov.in",
    kgidNumber: "KGID78901",
    mobileNumber: "3210987654",
    postAppliedFor: "District Health Officer",
    mbbs_institution: "Kempegowda Institute of Medical Sciences",
    current_posting_designation: "Medical Officer",
    status: "Approved",
    submittedAt: "2025-05-02T13:25:00Z",
  },
  {
    id: 8,
    fullName: "Dr. Lakshmi Narayana",
    email: "lakshmi.narayana@health.gov.in",
    kgidNumber: "KGID89012",
    mobileNumber: "2109876543",
    postAppliedFor: "Taluk Health Officer",
    mbbs_institution: "JSS Medical College",
    current_posting_designation: "Medical Officer",
    status: "Pending",
    submittedAt: "2025-05-11T15:40:00Z",
  },
  {
    id: 9,
    fullName: "Dr. Ramesh Joshi",
    email: "ramesh.joshi@health.gov.in",
    kgidNumber: "KGID90123",
    mobileNumber: "1098765432",
    postAppliedFor: "Deputy Director",
    mbbs_institution: "Kasturba Medical College",
    current_posting_designation: "District Health Officer",
    status: "Rejected",
    submittedAt: "2025-05-01T12:05:00Z",
  },
  {
    id: 10,
    fullName: "Dr. Sunitha Devi",
    email: "sunitha.devi@health.gov.in",
    kgidNumber: "KGID01234",
    mobileNumber: "9087654321",
    postAppliedFor: "Joint Director",
    mbbs_institution: "Bangalore Medical College",
    current_posting_designation: "Taluk Health Officer",
    status: "Pending",
    submittedAt: "2025-05-13T10:15:00Z",
  },
];

export default SubmissionsTable;
