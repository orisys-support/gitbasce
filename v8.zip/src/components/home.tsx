import React from "react";
import { Link } from "react-router-dom";
import UserForm from "./UserForm";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const Home = () => {
  const [showForm, setShowForm] = React.useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white flex flex-col items-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="w-full max-w-4xl">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <img
              src="https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=200&q=80"
              alt="Health Department Logo"
              className="h-24 w-auto"
            />
          </div>
          <h1 className="text-3xl font-extrabold text-primary sm:text-4xl">
            Health and Family Welfare Department
          </h1>
          <p className="mt-3 text-xl text-muted-foreground">
            Application for Administrative Post
          </p>
        </div>

        {!showForm ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-12">
            <Card className="shadow-md hover:shadow-lg transition-shadow duration-300 border-t-4 border-t-primary">
              <CardHeader>
                <CardTitle className="text-center text-primary">
                  Fill Application Form
                </CardTitle>
                <CardDescription className="text-center">
                  Submit your application for administrative post
                </CardDescription>
              </CardHeader>
              <CardContent className="flex justify-center">
                <img
                  src="https://api.dicebear.com/7.x/avataaars/svg?seed=application"
                  alt="Application"
                  className="w-32 h-32"
                />
              </CardContent>
              <CardFooter className="flex justify-center">
                <Button onClick={() => setShowForm(true)} className="w-full">
                  Start Application
                </Button>
              </CardFooter>
            </Card>

            <Card className="shadow-md hover:shadow-lg transition-shadow duration-300 border-t-4 border-t-secondary">
              <CardHeader>
                <CardTitle className="text-center text-secondary">
                  Admin Portal
                </CardTitle>
                <CardDescription className="text-center">
                  Access the administrative dashboard
                </CardDescription>
              </CardHeader>
              <CardContent className="flex justify-center">
                <img
                  src="https://api.dicebear.com/7.x/avataaars/svg?seed=admin"
                  alt="Admin"
                  className="w-32 h-32"
                />
              </CardContent>
              <CardFooter className="flex justify-center">
                <Link to="/admin/login" className="w-full">
                  <Button variant="secondary" className="w-full">
                    Admin Login
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          </div>
        ) : (
          <>
            <div className="flex justify-between mb-4 items-center">
              <Button
                variant="outline"
                onClick={() => setShowForm(false)}
                className="text-sm"
              >
                ← Back to Options
              </Button>
              <Link to="/admin/login">
                <Button variant="outline" className="text-sm">
                  Admin Login
                </Button>
              </Link>
            </div>
            <UserForm />
          </>
        )}

        <div className="mt-8 text-center text-sm text-muted-foreground">
          <p>
            Having trouble with the application? Contact support at{" "}
            <a
              href="mailto:support@healthdept.gov.in"
              className="text-primary hover:text-primary/80"
            >
              support@healthdept.gov.in
            </a>
          </p>
          <p className="mt-2">
            Application URL:{" "}
            <span className="font-medium">http://bt.orisys.in:3001/</span>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Home;
