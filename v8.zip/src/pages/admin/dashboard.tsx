import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { DownloadIcon, LogOutIcon, SearchIcon, FilterIcon } from "lucide-react";
import SubmissionsTable from "@/components/admin/SubmissionsTable";
import { isAuthenticated, logout, getAuthToken } from "@/lib/auth";
import { fetchSubmissions, exportSubmissionsToExcel } from "@/lib/api";
import { useToast } from "@/components/ui/use-toast";

const AdminDashboard = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [dateRange, setDateRange] = useState("all");
  const [submissions, setSubmissions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();
  const { toast } = useToast();

  // Check authentication and load submissions on component mount
  useEffect(() => {
    if (!isAuthenticated()) {
      navigate("/admin/login");
      return;
    }

    loadSubmissions();
  }, [navigate]);

  const loadSubmissions = async () => {
    try {
      setLoading(true);
      const token = getAuthToken();
      if (!token) {
        throw new Error("Authentication token not found");
      }

      // Make API call to fetch submissions
      const data = await fetchSubmissions(token);
      setSubmissions(data);
      setError(null);
    } catch (err) {
      console.error("Failed to load submissions:", err);
      setError("Failed to load submissions. Please try again.");
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load submissions. Please try again.",
      });
    } finally {
      setLoading(false);
    }
  };

  // Calculate stats from actual data
  const stats = {
    totalSubmissions: submissions.length,
    pendingReview: submissions.filter((sub) => sub.status === "Pending").length,
    completedForms: submissions.filter((sub) => sub.status === "Approved")
      .length,
    recentSubmissions: submissions.filter((sub) => {
      const submittedDate = new Date(sub.submittedAt);
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      return submittedDate >= yesterday;
    }).length,
  };

  const handleLogout = () => {
    logout();
    navigate("/admin/login");
  };

  const handleExport = async (format: string) => {
    try {
      const token = getAuthToken();
      if (!token) {
        throw new Error("Authentication token not found");
      }

      const blob = await exportSubmissionsToExcel([], token);

      // Create download link
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `submissions-${new Date().toISOString().split("T")[0]}.xlsx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: "Export Successful",
        description: "The submissions have been exported to Excel format.",
      });
    } catch (err) {
      console.error("Export error:", err);
      toast({
        variant: "destructive",
        title: "Export Failed",
        description: "Failed to export submissions. Please try again.",
      });
    }
  };

  const handleTableExport = async (selectedIds: number[]) => {
    try {
      const token = getAuthToken();
      if (!token) {
        throw new Error("Authentication token not found");
      }

      const blob = await exportSubmissionsToExcel(selectedIds, token);

      // Create download link
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `selected-submissions-${new Date().toISOString().split("T")[0]}.xlsx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: "Export Successful",
        description: `${selectedIds.length} submissions have been exported to Excel format.`,
      });
    } catch (err) {
      console.error("Export error:", err);
      toast({
        variant: "destructive",
        title: "Export Failed",
        description: "Failed to export submissions. Please try again.",
      });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container flex h-16 items-center justify-between px-4">
          <h1 className="text-2xl font-bold">Admin Dashboard</h1>
          <Button variant="ghost" onClick={handleLogout}>
            <LogOutIcon className="mr-2 h-4 w-4" />
            Logout
          </Button>
        </div>
      </header>

      {/* Main content */}
      <main className="container px-4 py-6">
        {/* Stats cards */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">
                Total Submissions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalSubmissions}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">
                Pending Review
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.pendingReview}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">
                Completed Forms
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.completedForms}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">
                Recent Submissions (24h)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {stats.recentSubmissions}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters and actions */}
        <div className="my-6 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div className="flex flex-1 items-center gap-2">
            <div className="relative flex-1">
              <SearchIcon className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search submissions..."
                className="pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
              </SelectContent>
            </Select>
            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Date range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Time</SelectItem>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="week">This Week</SelectItem>
                <SelectItem value="month">This Month</SelectItem>
                <SelectItem value="year">This Year</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => handleExport("csv")}>
              <DownloadIcon className="mr-2 h-4 w-4" />
              Export CSV
            </Button>
            <Button variant="outline" onClick={() => handleExport("excel")}>
              <DownloadIcon className="mr-2 h-4 w-4" />
              Export Excel
            </Button>
          </div>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="all" className="mt-6">
          <TabsList>
            <TabsTrigger value="all">All Submissions</TabsTrigger>
            <TabsTrigger value="pending">
              Pending
              <Badge variant="secondary" className="ml-2">
                {stats.pendingReview}
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="recent">Recent</TabsTrigger>
          </TabsList>
          <TabsContent value="all" className="mt-4">
            {loading ? (
              <div className="flex justify-center items-center h-64">
                <p>Loading submissions...</p>
              </div>
            ) : error ? (
              <div className="flex justify-center items-center h-64">
                <p className="text-red-500">{error}</p>
                <Button
                  variant="outline"
                  onClick={loadSubmissions}
                  className="ml-4"
                >
                  Retry
                </Button>
              </div>
            ) : (
              <SubmissionsTable
                submissions={submissions}
                searchQuery={searchQuery}
                filterStatus={filterStatus}
                dateRange={dateRange}
                onExport={handleTableExport}
                onSearch={setSearchQuery}
                onFilter={(filter) => setFilterStatus(filter.status || "all")}
              />
            )}
          </TabsContent>
          <TabsContent value="pending" className="mt-4">
            {loading ? (
              <div className="flex justify-center items-center h-64">
                <p>Loading submissions...</p>
              </div>
            ) : (
              <SubmissionsTable
                submissions={submissions.filter(
                  (sub) => sub.status === "Pending",
                )}
                searchQuery={searchQuery}
                filterStatus="Pending"
                dateRange={dateRange}
                onExport={handleTableExport}
                onSearch={setSearchQuery}
                onFilter={(filter) => setFilterStatus(filter.status || "all")}
              />
            )}
          </TabsContent>
          <TabsContent value="recent" className="mt-4">
            {loading ? (
              <div className="flex justify-center items-center h-64">
                <p>Loading submissions...</p>
              </div>
            ) : (
              <SubmissionsTable
                submissions={submissions.filter((sub) => {
                  const submittedDate = new Date(sub.submittedAt);
                  const yesterday = new Date();
                  yesterday.setDate(yesterday.getDate() - 1);
                  return submittedDate >= yesterday;
                })}
                searchQuery={searchQuery}
                filterStatus={filterStatus}
                dateRange="today"
                onExport={handleTableExport}
                onSearch={setSearchQuery}
                onFilter={(filter) => setFilterStatus(filter.status || "all")}
              />
            )}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default AdminDashboard;
