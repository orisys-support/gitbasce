-- Database schema for Health and Family Welfare Department Administrative Post Application System

-- Create database
CREATE DATABASE health_family_welfare_dept;
USE health_family_welfare_dept;

-- Admin users table
CREATE TABLE admin_users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  role ENUM('admin', 'super_admin') NOT NULL DEFAULT 'admin',
  last_login DATETIME,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Applications table
CREATE TABLE applications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  -- Section 1: Personal Details
  post_applied_for VARCHAR(100) NOT NULL,
  full_name VARCHAR(100) NOT NULL,
  kgid_number VARCHAR(50) NOT NULL,
  date_of_birth DATE NOT NULL,
  mobile_number VARCHAR(15) NOT NULL,
  email VARCHAR(100) NOT NULL,
  
  -- Section 2: Educational Qualifications & Trainings
  mbbs_institution VARCHAR(255) NOT NULL,
  mbbs_year VARCHAR(4) NOT NULL,
  pg_degree VARCHAR(100),
  pg_institution VARCHAR(255),
  pg_university VARCHAR(255),
  pg_year VARCHAR(4),
  deputed_by_government BOOLEAN DEFAULT FALSE,
  specialist_service TEXT,
  training_hospital_admin BOOLEAN DEFAULT FALSE,
  
  -- Section 3: Service Details
  date_initial_appointment DATE NOT NULL,
  sl_no_in_order VARCHAR(50) NOT NULL,
  order_no_date VARCHAR(100) NOT NULL,
  date_appointment_contract DATE,
  appointing_authority VARCHAR(255),
  compulsory_rural_service_places TEXT,
  compulsory_rural_service_duration VARCHAR(100),
  probation_declaration TEXT,
  past_designations TEXT,
  current_posting_designation VARCHAR(100) NOT NULL,
  current_posting_period VARCHAR(100) NOT NULL,
  contract_service_details TEXT,
  
  -- Service Bonds
  timebound_6year BOOLEAN DEFAULT FALSE,
  timebound_6year_order VARCHAR(100),
  timebound_6year_date DATE,
  timebound_13year BOOLEAN DEFAULT FALSE,
  timebound_13year_order VARCHAR(100),
  timebound_13year_date DATE,
  timebound_20year BOOLEAN DEFAULT FALSE,
  timebound_20year_order VARCHAR(100),
  timebound_20year_date DATE,
  spouse_govt_service TEXT,
  administrative_roles TEXT,
  additional_charges TEXT,
  
  -- Section 4: Performance and Achievements
  significant_achievements TEXT,
  special_achievements TEXT,
  
  -- Section 5: Departmental Enquiry / Disciplinary Record
  departmental_enquiries TEXT,
  suspension_periods TEXT,
  punishments_received TEXT,
  criminal_proceedings TEXT,
  pending_legal_matters TEXT,
  
  -- Section 6: Declaration & Undertaking
  declaration_date DATE NOT NULL,
  declaration_place VARCHAR(100) NOT NULL,
  
  -- Application status and metadata
  status ENUM('Pending', 'Approved', 'Rejected', 'Under Review') NOT NULL DEFAULT 'Pending',
  reviewer_id INT,
  review_notes TEXT,
  submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  -- Foreign key
  FOREIGN KEY (reviewer_id) REFERENCES admin_users(id) ON DELETE SET NULL
);

-- Application documents table (for storing file uploads)
CREATE TABLE application_documents (
  id INT AUTO_INCREMENT PRIMARY KEY,
  application_id INT NOT NULL,
  document_type ENUM(
    'identity_proof', 
    'mbbs_certificate', 
    'pg_certificate', 
    'training_certificate', 
    'service_record', 
    'achievement_proof', 
    'other'
  ) NOT NULL,
  document_name VARCHAR(255) NOT NULL,
  file_path VARCHAR(255) NOT NULL,
  file_size INT NOT NULL,
  mime_type VARCHAR(100) NOT NULL,
  uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  -- Foreign key
  FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE
);

-- Application status history table (for tracking status changes)
CREATE TABLE application_status_history (
  id INT AUTO_INCREMENT PRIMARY KEY,
  application_id INT NOT NULL,
  previous_status ENUM('Pending', 'Approved', 'Rejected', 'Under Review'),
  new_status ENUM('Pending', 'Approved', 'Rejected', 'Under Review') NOT NULL,
  changed_by INT NOT NULL,
  notes TEXT,
  changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  -- Foreign keys
  FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE,
  FOREIGN KEY (changed_by) REFERENCES admin_users(id) ON DELETE CASCADE
);

-- Insert default admin user
INSERT INTO admin_users (username, password_hash, full_name, email, role) 
VALUES ('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'System Administrator', 'admin@healthdept.gov.in', 'super_admin');
-- Note: The password hash above is for 'password' - in a real system, use proper password hashing

-- Create indexes for better performance
CREATE INDEX idx_applications_status ON applications(status);
CREATE INDEX idx_applications_post ON applications(post_applied_for);
CREATE INDEX idx_applications_kgid ON applications(kgid_number);
CREATE INDEX idx_applications_name ON applications(full_name);
