-- Create database if it doesn't exist
CREATE DATABASE IF NOT EXISTS form;

USE form;

-- Create admin_users table
CREATE TABLE IF NOT EXISTS admin_users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(100) NOT NULL,
  role VARCHAR(20) NOT NULL DEFAULT 'admin',
  email VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  last_login TIMESTAMP NULL
);

-- Create applications table
CREATE TABLE IF NOT EXISTS applications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  post_applied_for VARCHAR(100) NOT NULL,
  full_name VARCHAR(100) NOT NULL,
  kgid_number VARCHAR(50) NOT NULL,
  date_of_birth DATE NOT NULL,
  mobile_number VARCHAR(15) NOT NULL,
  email VARCHAR(100) NOT NULL,
  mbbs_institution VARCHAR(100) NOT NULL,
  mbbs_year VARCHAR(10) NOT NULL,
  pg_degree VARCHAR(100),
  pg_institution VARCHAR(100),
  pg_university VARCHAR(100),
  pg_year VARCHAR(10),
  deputed_by_government BOOLEAN DEFAULT FALSE,
  specialist_service TEXT,
  training_hospital_admin BOOLEAN DEFAULT FALSE,
  date_initial_appointment DATE NOT NULL,
  sl_no_in_order VARCHAR(50) NOT NULL,
  order_no_date VARCHAR(100) NOT NULL,
  date_appointment_contract DATE,
  appointing_authority VARCHAR(100),
  compulsory_rural_service_places TEXT,
  compulsory_rural_service_duration VARCHAR(100),
  probation_declaration VARCHAR(100),
  past_designations TEXT,
  current_posting_designation VARCHAR(100) NOT NULL,
  current_posting_period VARCHAR(100) NOT NULL,
  contract_service_details TEXT,
  timebound_6year BOOLEAN DEFAULT FALSE,
  timebound_6year_order VARCHAR(100),
  timebound_6year_date DATE,
  timebound_13year BOOLEAN DEFAULT FALSE,
  timebound_13year_order VARCHAR(100),
  timebound_13year_date DATE,
  timebound_20year BOOLEAN DEFAULT FALSE,
  timebound_20year_order VARCHAR(100),
  timebound_20year_date DATE,
  spouse_govt_service TEXT,
  administrative_roles TEXT,
  additional_charges TEXT,
  significant_achievements TEXT,
  special_achievements TEXT,
  departmental_enquiries TEXT,
  suspension_periods TEXT,
  punishments_received TEXT,
  criminal_proceedings TEXT,
  pending_legal_matters TEXT,
  declaration_date DATE NOT NULL,
  declaration_place VARCHAR(100) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Pending',
  reviewer_id INT,
  review_notes TEXT,
  submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (reviewer_id) REFERENCES admin_users(id)
);

-- Create application_status_history table
CREATE TABLE IF NOT EXISTS application_status_history (
  id INT AUTO_INCREMENT PRIMARY KEY,
  application_id INT NOT NULL,
  previous_status VARCHAR(20) NOT NULL,
  new_status VARCHAR(20) NOT NULL,
  changed_by INT NOT NULL,
  notes TEXT,
  changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (application_id) REFERENCES applications(id),
  FOREIGN KEY (changed_by) REFERENCES admin_users(id)
);

-- Insert default admin user (username: admin, password: admin123)
INSERT INTO admin_users (username, password_hash, full_name, role, email)
VALUES ('admin', '$2b$10$3euPcmQFCiblsZeEu5s7p.9wVdtxDGpCH7lRXlIzQKnLELCfZ3ad2', 'Admin User', 'administrator', 'admin@health.gov.in')
ON DUPLICATE KEY UPDATE full_name = 'Admin User';
